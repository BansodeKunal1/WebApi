﻿using System;
using TechTalk.SpecFlow;

namespace automation
{
    [Binding]
    public class ToDoItemsSteps
    {
        [Given(@"todo list already exist")]
        public void GivenTodoListAlreadyExist()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"get all todo list")]
        public void WhenGetAllTodoList()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"todo list are available")]
        public void ThenTodoListAreAvailable()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
