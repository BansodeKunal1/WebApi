using System;
using Xunit;

namespace acceptance
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
